/**
 * MyQueue.java
 * Name: Bella Hardy
 * Email: ihardy@ucsd.edu
 * Sources used: Lecutes and discussion
 * 
 * This file contains a MyDeque class, which 
 * is an implementation in a circular array bassed form 
 * to be used in the stack, queue, and deque. elements can 
 * be added, removed, and looked at as well as other 
 * methods to expand capacity or look at size. 
 * 
 */

 /**
  * This class contains methods which is an
 * implementation in a circular array bassed form 
 * to be used in the stack, queue, and deque. elements can 
 * be added, removed, and looked at as well as other 
 * methods to expand capacity or look at size. 
 * 
  */
public class MyDeque<E> implements DequeInterface<E> {
    MyQueue<E> theQueue;

    Object[] data;
    int size = 0;
    int rear = 0 ;
    int front = 0 ;
    private static final int DEFAULTCAPACITY = 10;
    public static final int increaseCapacity = 2;

    /**
     * constructor to make a new array 
     * with size of initial capacity and 
     * set instance variables
     * @param initialCapacity - capacity of the new array
     * @return none
     */
    public MyDeque(int initialCapacity){
        if (initialCapacity < 0){
            throw new IllegalArgumentException();   
        }
        front = 0;
        rear = 0;
        size = 0;
        
        data = new Object[initialCapacity];
    }

    /**
     * returns number of valid aruments in the array
     * @return size - number of valid aruments in the array
     */
    public int size(){
        return size;
    }

    /**
     * capcity is reset to 10 if it is 0 originally but 
     * double the orignal ammount if it is 
     * not 0 originally 
     * @param none
     * @return none
     */
    public void expandCapacity(){
        //creates a holder array to store values of data
        Object[] holder = new Object[data.length];
        //sets capacity of data to the default capacity 
        if(data.length == 0){
            data = new Object[DEFAULTCAPACITY];
        }
        else{
            //transfers all the values in data to holder
            for(int i = 0; i < data.length; i++){
                holder[i] = data[i];
            }
            //sets capacity of data to double the original capacity 
            data = new Object[data.length*increaseCapacity];
            //variable to keep track of spot in data
            int sort = 0;
            //variable to keep track of spot in order of front to end
            int frontHolder = front;
            //transfers all the values in holder to data in order
            //of front to rear
            while(sort < holder.length){
                if(frontHolder == holder.length){
                    frontHolder = 0;
                }
                data[sort] = holder[frontHolder];
                frontHolder++;
                sort++;
            }
            front = 0;
            rear = size - 1;
        }    
    }

    /**
     * adds an element to the front of the
     * circuar array
     * @param element - is the element being added
     * @return none
     */
    public void addFirst(E element){    
        if(element == null){
            throw new NullPointerException();
        }
        //checks if an addion will be legal
        //if not expand
        if(size == data.length){
            expandCapacity();
        }
        //sets front to element
        if(size == 0){
            data[front] = element;
        }
        //if there is already data at index 0 go
        //to the end of the actual array
        else if(front - 1 < 0){
            front = data.length - 1;
            data[front] = element;
        }
        //move the front to the next spot up in the array
        else{
            front--;
            data[front] = element;
        }
        size++;
    }
    
    /**
     * adds and element to the end of the
     * circular array
     * @param element - element being added into the 
     *                  array
     * @return none
     */
    public void addLast(E element){
        if(element == null){
            throw new NullPointerException();
        }
        //checks if an addion will be legal
        //if not expand
        if(size == data.length){
            expandCapacity();
        }
        //sets rear to element
        if(size == 0){
            data[rear] = element;
        }
        //if there is already data at index 0 go
        //to the beginning of the actual array
        else if(rear + 1 >= data.length){
            rear = 0;
            data[rear] = element;
        }
        //move the end to the next spot back in the array
        else{
            rear++;
            data[rear] = element;
        }
        size++;

    }

    /**
     * removes the element at the front of the
     * circular array
     * @param none
     * @return holder - the element removed
     */
    public E removeFirst(){
        //checks for empty array
        if(size == 0){
            return null;
        }
        //checks if there is only one element
        else if(size == 1){
            //set to null and return orginal values
            //while updating front and size
            E holder = (E)data[front];
            data[front]=null;
            size--;
            return holder;
        }
        else{
            //set to null and return orginal values
            //while updating front and size
            E holder = (E)data[front];
            data[front]=null;
            front++;
            size--; 
            return holder;
        }

    }

    /**
     * removes the element at the rear of the
     * circular array
     * @param none
     * @return holder - the element removed
     */
    public E removeLast(){
        //checks for empty array
        if(size == 0){
            return null;
        }
        //checks if there is only one element
        else if(size == 1){
            //set to null and return orginal values
            //while updating rear and size
            E holder = (E)data[rear];
            data[rear]=null;
            rear--;
            size--;
            return holder;
        }
        else {
            //set to null and return orginal values
            //while updating rear and size
            E holder = (E)data[rear];
            data[rear]=null;
            rear--;
            size--;
            return holder;
        }
    }

    /**
     * looks at the element at the front of the
     * circular array
     * @param none
     * @return element at the front of the circular array
     */
    public E peekFirst(){
        //returns null if empty
        if(size == 0){
            return null;
        }
        //returns the element at the front
        else{
            return (E)data[front];
        }
    }

    /**
     * looks at the element at the rear of the
     * circular array
     * @param none
     * @return element at the rear of the circular array
     */
    public E peekLast(){
        //returns null if empty
        if(size == 0){
            return null;
        }
        //returns the element at the rear
        else{
            return (E)data[rear];
        }
    }
}

