/**
 * CustomTester.java
 * Name: Bella Hardy
 * ID: A16369822
 * Email: ihardy@ucsd.edu
 * Sources used: Lectures and discussion
 * 
 * file tests edge cases that do not exist in 
 * the public tester so that all casses are addressed.
 */

import org.junit.*;
import static org.junit.Assert.*;

/**
 * class tests edge cases that do not exist in 
 * the public tester so that all casses are addressed.
 * 
 * IMPORTANT: Do not change the method names and points are awarded
 * only if your test cases cover cases that the public tester file
 * does not take into account.
 */
public class CustomTester {
    // ----------------MyDeque class----------------
    /**
     * Test the constructor when [illegal argument expected]
     */
    @Test (expected = IllegalArgumentException.class)
    public void testMyDequeConstructor() {
        MyDeque<Integer> deque = new MyDeque<>(-3);
    }

    /**
     * Test the expandCapacity method when [default needed and double needed]
     */
    @Test
    public void testMyDequeExpandCapacity() {
        MyDeque<Integer> deque = new MyDeque<>(0);
        deque.addFirst(9);
        assertEquals("Capacity should be 10", 10,
               deque.data.length);
        deque.addFirst(2);
        deque.addFirst(5);
        deque.addFirst(92);
        deque.addFirst(10);
        deque.addLast(8);
        deque.addLast(1);
        deque.addFirst(18);
        deque.addFirst(12);
        deque.addLast(19);
        deque.addLast(83);
        assertEquals("checking size", 11 ,deque.size());
        assertEquals("Capacity should be 20", 20,
                deque.data.length);

    }

    /**
     * Test the addFirst method when [expand capacity is needed]
     */
    @Test
    public void testAddFirst() {
        MyDeque<Integer> dequeCheck = new MyDeque<>(0);
        dequeCheck.addFirst(1);
        assertEquals("Capacity should be 10", 10,
                dequeCheck.data.length);
        assertEquals("checking placement", 
        Integer.valueOf(1),dequeCheck.peekFirst());
        assertEquals("checking placement", 
        Integer.valueOf(1),dequeCheck.peekLast());
        assertEquals("checking size", 1 ,dequeCheck.size());
        dequeCheck.addFirst(4);
        assertEquals("checking placement", 
        Integer.valueOf(4),dequeCheck.peekFirst());
        assertEquals("checking placement", 
        Integer.valueOf(1),dequeCheck.peekLast());
        assertEquals("checking size", 2,dequeCheck.size());



    }

    /**
     * Test the addLast method when [expand capacity is needed]
     */
    @Test
    public void testAddLast() {
        MyDeque<Integer> dequeCheck = new MyDeque<>(0);
        dequeCheck.addLast(1);
        assertEquals("Capacity should be 10", 10,
                dequeCheck.data.length);
        assertEquals("checking placement", 
        Integer.valueOf(1),dequeCheck.peekFirst());
        assertEquals("checking placement", 
        Integer.valueOf(1),dequeCheck.peekLast());
        assertEquals("checking size", 1 ,dequeCheck.size());
        dequeCheck.addLast(4);
        assertEquals("checking placement", 
        Integer.valueOf(4),dequeCheck.peekLast());
        assertEquals("checking placement", 
        Integer.valueOf(1),dequeCheck.peekFirst());
        assertEquals("checking size", 2,dequeCheck.size());

    }

    /**
     * Test the removeFirst method when [empty then adding first and last]
     */
    @Test
    public void testRemoveFirst() {
        MyDeque<Integer> deque = new MyDeque<>(30);
        assertEquals("null expected",null ,deque.removeFirst());
        deque.addFirst(1);
        deque.addFirst(2);
        deque.addFirst(3);
        deque.addLast(4);
        deque.addLast(5);
        deque.addLast(6);
        assertEquals("checking value",
        Integer.valueOf(3) ,deque.removeFirst());
        assertEquals("peeking", 
        Integer.valueOf(2), deque.peekFirst());
        assertEquals("peeking", 
        Integer.valueOf(6), deque.peekLast());

        
    }

    /**
     * Test the removeLast method when [empty]
     */
    @Test
    public void testRemoveLast() {
        MyDeque<Integer> deque = new MyDeque<>(30);
        assertEquals("null expected",null ,deque.removeLast());
        deque.addFirst(1);
        deque.addFirst(2);
        deque.addFirst(3);
        deque.addLast(4);
        deque.addLast(5);
        deque.addLast(6);
        assertEquals("checking value",
        Integer.valueOf(6) , deque.removeLast());
        assertEquals("peeking", 
        Integer.valueOf(3), deque.peekFirst());
        assertEquals("peeking", 
        Integer.valueOf(5), deque.peekLast());

    }

    /**
     * Test the peekFirst method when [empty and then adding first and last]
     */
    @Test
    public void testPeekFirst(){
        MyDeque<Integer> deque= new MyDeque<>(12);
        assertEquals("expecting null", null, deque.peekFirst());
        deque.addFirst(2);
        deque.addFirst(1);
        deque.addLast(9);
        assertEquals("chekcing first", Integer.valueOf(1), deque.peekFirst());
        assertEquals("checking size", 3, deque.size());
        assertEquals("checking length", 12, deque.data.length);
    }

    /**
     * Test the peekLast method when [null and adding first and last at the same time]
     */
    @Test
    public void testPeekLast(){
        MyDeque<Integer> deque= new MyDeque<>(12);
        assertEquals("expecting null", null, deque.peekLast());
        deque.addFirst(2);
        deque.addFirst(1);
        deque.addLast(9);
        assertEquals("checking last", Integer.valueOf(9), deque.peekLast());
        assertEquals("checking size", 3, deque.size());
        assertEquals("checking length", 12, deque.data.length);

    }

    // ----------------MyStack class----------------
    /**
     * Test MyStack when [both pop and push are used]
     */
    @Test
    public void testMyStack(){
        MyStack<Integer> newstack = new MyStack<>(12);

        assertEquals("Capacity should be 12", 12, 
        newstack.theStack.data.length);
        assertEquals("Size should be 0", 0, 
        newstack.theStack.size);
        assertEquals("Front should be 0", 0,
        newstack.theStack.front);
        assertEquals("Rear should be 0", 0, 
        newstack.theStack.rear);
        newstack.push(1);
        newstack.push(8);
        newstack.push(10);
        newstack.push(0);
        newstack.push(12);
        newstack.pop();
        newstack.pop();
        assertEquals("Front should be 0", 0, 
        newstack.theStack.front);
        assertEquals("rear should be 2", 2, 
        newstack.theStack.rear);
        assertEquals("rear should be 10", Integer.valueOf(10), 
        newstack.theStack.peekLast());
        assertEquals("size", 3, newstack.theStack.size);

    }

    // ----------------MyQueue class----------------
    /**
     * Test MyQueue when [multiple methods are called, peek, eneueue, dequeue]
     */
    @Test
    public void testMyQueue(){
        MyQueue<Integer> newqueue = new MyQueue<>(3);
        newqueue.enqueue(9);
        newqueue.enqueue(10);
        newqueue.enqueue(2);
        newqueue.enqueue(8);
        assertEquals("checking size", 4, newqueue.size());
        assertEquals("checking length", 6, newqueue.theQueue.data.length);
        assertEquals("checking top", Integer.valueOf(9), newqueue.peek());
        newqueue.dequeue();
        assertEquals("checking length", 6, newqueue.theQueue.data.length);
        assertEquals("checking size", 3, newqueue.size());
        assertEquals("checking top", Integer.valueOf(10), newqueue.peek());
    }
}
